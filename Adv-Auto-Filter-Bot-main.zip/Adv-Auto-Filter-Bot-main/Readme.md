# Adv Auto Filter Bot

<p align="center">
  <a href="https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot/stargazers">
    <img src="https://img.shields.io/github/stars/AlbertEinsteinTG/Adv-Auto-Filter-Bot?style=social">

  </a>
  
  <a href="https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot/fork">
    <img src="https://img.shields.io/github/forks/AlbertEinsteinTG/Adv-Auto-Filter-Bot?label=Fork&style=social">

  </a>  
</p>

_This Just A Simple Hand Auto Filter Bot For Searching Files From Channel..._

_Just Sent Any Text I Will Search In All Connected Chat And Reply You With The Message link_

_You Can Even Connected To 3 Channels At A Time..._

## Usage

_=> Add Bot To Any Channel As Admin With Add Members/ Invite Users Via Link_

_=> Copy Channel ID_

_=> Use `/connect {channel id}` In Your Group To Connect With The Group_

_=> Use `/disconnect {channel id}` In Your Group To Disconnect From Your Group_

_=> Use `/delall` In Your Group To Clear All Your Group  Connections (Owner Only)_

_Now You Are All Set And Ready To Go..._

_Just Send Any Text Will Try To Lookup In Channel And Provide You The Link_

### Pre Requisites 

_Your Bot Token From @BotFather_

_Your APP ID And API Harsh From [Telegram](http://www.my.telegram.org) or [@UseTGXBot](http://www.telegram.dog/UseTGXBot)_

_Your User Session String Obtained From [@PyrogramStringBot](http://www.telegram.dog/PyrogramStringBot)_

_Mongo DB URL Obtained From [Mongo DB](http://www.mongodb.com)_

### Deploy:
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot)

### TODO :

- [ ] - Brodcast
- [ ] - Better Codes
- [x] - Rewrite To Motor Asyncious Driver

PR's Are Very Welcome And If Found Any Bug Feel Free To Open A Issue...
If YOu Found This Repo As Usefull A Star And Fork Would Be Amazing..😋

## Credits

 - Thanks To Dan For His Awsome [Libary](https://github.com/pyrogram/pyrogram)
