#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) @AlbertEinsteinTG

class Translation(object):
    
    START_TEXT = """<b>Hai {}!!</b>
<i>Am Just A Simple Hand Auto Filter Bot_ Bot For Searching Files From Channel...

Just Sent Any Text I Will Search In All Connected Chat And Reply You With The Message link

You Can Even Connected To 3 Channels At A Time...</i>"""    
    
    HELP_TEXT = """<i><u>Usage Guide</u></i>

<i>=> Add Bot To Any Channel As Admin With Add Members/ Invite Users Via Link

=> Copy Channel ID

=> Use <code>/connect {channel id}</code> In Your Group To Connect With The Group

=> Use <code>/disconnect {channel id}</code> In Your Group To Disconnect From Your Group

=> Use <code>/delall</code> In Your Group To Clear All Your Group  Connections (Owner Only)

Now You Are All Set And Ready To Go...

Just Send Any Text Will Try To Lookup In Channel And Provide You The Link</i>
"""
    
    ABOUT_TEXT = """<b>➥ Name</b> : <code>Adv Auto Filter Bot</code>

<b>➥ Creator</b> : <b><i><a herf="https://t.me/AlbertEinstein_TG">AlbertEinstein_TG</a></i></b>

<b>➥ Language</b> : <code>Python3</code>

<b>➥ Library</b> : <i><a herf="https://docs.pyrogram.org">Pyrogram Asyncio 1.13.0</a></i>

<b>➥ Source Code</b> : <i><a herf="https://github.com/AlbertEinsteinTG/Adv-Auto-Filter-Bot">GitHub</a></i>
"""
